# Hello World Program

A simple Python program that prints "Hello World".

## Code

```python
print("Hello World")
```

## Output

```
Hello World
```
